<?php
namespace Cis\Comment\Controller\Index;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Store\Model\StoreManagerInterface as storeManage;
use Magento\Checkout\Model\Cart as CustomerCart;

 // inject  \Magento\Checkout\Model\Cart $cart;

class File extends \Magento\Framework\App\Action\Action
{
    /*
     * @return \Magento\Framework\Controller\ResultInterface
     */
	/*   public function __construct(
		 \Magento\Framework\App\Action\Context $context,	   
          CustomerCart $cart      
    ) {
		/*parent::__construct(
         $context		
		 );*/
    

    public function execute(){


             
            if(isset($_POST["order_ref"])){                
                
				$om =   \Magento\Framework\App\ObjectManager::getInstance();
				$storeManager = $om->get('\Magento\Store\Model\StoreManagerInterface');
				$baseurl= $storeManager->getStore()->getBaseUrl();
				$cart = $om->create('Magento\Checkout\Model\Cart')->getQuote();
				$cart->setOrderRef($_POST["order_ref"]);
				$cart->setDaysStart($_POST["days-start"]);
				$cart->setDaysEnd($_POST["days-end"]);
				$cart->setTimeStart($_POST["time-start"]);
				$cart->setTimeEnd($_POST["time-end"]);
				$cart->setComments($_POST["comments"]);
				$cart->save();
				
				echo "Information Updated sucessfully.";
				
                die;
                
				} else {                    
                
				echo "Information not Updated, please try again.";
				die;
				
                }
        }
	
	}
