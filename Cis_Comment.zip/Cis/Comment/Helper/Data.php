<?php 

namespace Cis\Comment\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\ScopeInterface;
use Mageplaza\Blog\Model\PostFactory;
use Mageplaza\Blog\Model\CategoryFactory;
use Mageplaza\Blog\Model\TagFactory;
use Mageplaza\Blog\Model\TopicFactory;

class Data extends AbstractHelper
{
	protected $storeManager;
	protected $objectManager;
	protected $postfactory;
	protected $categoryfactory;
	protected $tagfactory;
	protected $topicfactory;

	public function __construct(
		Context $context,
		ObjectManagerInterface $objectManager,
		StoreManagerInterface $storeManager,
		PostFactory $postFactory,
		CategoryFactory $categoryFactory,
		TagFactory $tagFactory,
		TopicFactory $topicFactory
	)
	{
		$this->objectManager   = $objectManager;
		$this->storeManager    = $storeManager;
		$this->postfactory     = $postFactory;
		$this->categoryfactory = $categoryFactory;
		$this->tagfactory      = $tagFactory;
		$this->topicfactory    = $topicFactory;
		parent::__construct($context);
	}

	public function getConfig($config_path)
{
    return $this->scopeConfig->getValue(
            $config_path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            );
}

}
?>
