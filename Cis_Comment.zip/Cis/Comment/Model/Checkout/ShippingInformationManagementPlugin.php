<?php

namespace Cis\Comment\Model\Checkout;

class ShippingInformationManagementPlugin
{

    protected $quoteRepository;

    public function __construct(
        \Magento\Quote\Model\QuoteRepository $quoteRepository
    ) {
        $this->quoteRepository = $quoteRepository;
    }

    /**
     * @param \Magento\Checkout\Model\ShippingInformationManagement $subject
     * @param $cartId
     * @param \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
     */
    public function beforeSaveAddressInformation(
        \Magento\Checkout\Model\ShippingInformationManagement $subject,
        $cartId,
        \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    ) {
        $extAttributes = $addressInformation->getExtensionAttributes(); 
	/*$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test2.log');
	$logger = new \Zend\Log\Logger();
	$logger->addWriter($writer);
	$logger->info(print_r($extAttributes, true));*/
        $deliveryDate = $extAttributes->getDeliveryDate();
        $orderref = $extAttributes->getOrderRef();

        $daysStart = $extAttributes->getDaysStart();
        $daysEnd = $extAttributes->getDaysEnd();

        $timeStart = $extAttributes->getTimeStart();
        $timeEnd   = $extAttributes->getTimeEnd();
        $comments  = $extAttributes->getComments();
		
        $quote = $this->quoteRepository->getActive($cartId);
        $quote->setDeliveryDate($deliveryDate);
	    $quote->setOrderRef($orderref);
        
         $quote->setDaysStart($daysStart);
         $quote->setDaysEnd($daysEnd);

        $quote->setTimeStart($timeStart);
        $quote->setTimeEnd($timeEnd);
        $quote->setComments($comments);
	
    }
}



