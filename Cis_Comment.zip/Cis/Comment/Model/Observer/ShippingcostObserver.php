<?php
/**
 * Created by PhpStorm.
 * User: eugen
 * Date: 27.11.2015
 * Time: 17:53
 */

namespace Cis\Comment\Model\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class ShippingcostObserver implements ObserverInterface
{
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectmanager
     */
    public function __construct(\Magento\Framework\ObjectManagerInterface $objectmanager)
    {
        $this->_objectManager = $objectmanager;
    }

    public function execute(EventObserver $observer)
    {  //$quote = $observer->getQuote();	
		$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/ship.log');
		$logger = new \Zend\Log\Logger();
		$logger->addWriter($writer);
		//	 $logger->info(print_r($quote, true));
		$logger->info('testing...');
		return true;
		 
    }
}