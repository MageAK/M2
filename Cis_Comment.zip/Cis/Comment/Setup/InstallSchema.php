<?php

namespace Cis\Comment\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
         $installer = $setup;
        $installer->startSetup();

        $installer->getConnection()->addColumn(
            $installer->getTable('quote'),
            'delivery_date',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'Delivery Date',
            ]
        );
		   $installer->getConnection()->addColumn(
            $installer->getTable('quote'),
            'order_ref',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'order_ref',
            ]
        );
    
         $installer->getConnection()->addColumn(
            $installer->getTable('quote'),
            'days_start',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'days_start',
            ]
        );

         $installer->getConnection()->addColumn(
            $installer->getTable('quote'),
            'days_end',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'days_end',
            ]
        );
        $installer->getConnection()->addColumn(
            $installer->getTable('quote'),
            'time_start',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'time_start',
            ]
        );
 
       $installer->getConnection()->addColumn(
            $installer->getTable('quote'),
            'time_end',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'time_end',
            ]
        );

        $installer->getConnection()->addColumn(
            $installer->getTable('quote'),
            'comments',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'comments',
            ]
        );


	 
        $installer->getConnection()->addColumn(
            $installer->getTable('sales_order'),
            'delivery_date',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'Delivery Date',
            ]
        );
		$installer->getConnection()->addColumn(
            $installer->getTable('sales_order'),
            'order_ref',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'order_ref',
            ]
        );
   
       $installer->getConnection()->addColumn(
            $installer->getTable('sales_order'),
            'days_start',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'days_start',
            ]
        );

       $installer->getConnection()->addColumn(
            $installer->getTable('sales_order'),
            'days_end',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'days_end',
            ]
        );


       $installer->getConnection()->addColumn(
            $installer->getTable('sales_order'),
            'time_start',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'time_start',
            ]
        );

       $installer->getConnection()->addColumn(
            $installer->getTable('sales_order'),
            'time_end',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'time_end',
            ]
        );

       $installer->getConnection()->addColumn(
            $installer->getTable('sales_order'),
            'comments',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'comments',
            ]
        );
		$installer->getConnection()->addColumn(
            $installer->getTable('sales_order'),
            'order_num',
            [
                'type' => 'text',
                'nullable' => false,
				 'length'=> 100,
                'comment' => 'order_num',
            ]
        );
		
        $setup->endSetup();    }
}
