<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Cis\Comment\Block;

class Agreements extends \Magento\CheckoutAgreements\Block\Agreements
{
     
     public function getHelperstatus()
    {
      
      return $this->_scopeConfig->getValue('cis_comment/active_display/enabled', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    
    }
}
