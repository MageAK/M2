require([ 'jquery', 'jquery/ui'], function(){
     
     jQuery(document).ready(function(){
          
          jQuery("#updated_data").live("click", function(){ 
                baseurl = jQuery('.logo').attr('href');   
                baseurl = baseurl + 'cis/index/file'; 
               //baseurl = 'http://localhost/Magento-CE-2.1.1/' + 'oye/index/file';             
                    if( jQuery('#days_start').val() != " "){
                        var order_ref = jQuery('input[name="order_ref_new"]:checked').val();
                        var days_start = jQuery('#days-start-new').find(":selected").val();
                        var days_end = jQuery('#days-end-new').find(":selected").val();
                        var time_start = jQuery('#time-start-new').find(":selected").val();
                        var time_end = jQuery('#time-end-new').find(":selected").val();
                        var comments = jQuery('textarea#order_comment_new').val();
                        var form_data = new FormData();                  
                        
                        form_data.append('order_ref',order_ref);
                        form_data.append('days-start', days_start);
                        form_data.append('days-end', days_end);
                        form_data.append('time-start',time_start);
                        form_data.append('time-end', time_end);
                        form_data.append('comments', comments);
                        jQuery.ajax({
                                    url: baseurl, // point to server-side PHP script 
                                    dataType: 'text',  // what to expect back from the PHP script, if anything
                                    cache: false,
                                    contentType: false,
                                    processData: false,
                                    data: form_data,                         
                                    type: 'post',
                                    success: function(php_script_response){
                                    jQuery('#success_msg').html(php_script_response);  
                                    jQuery('#success_msg').css('display', 'block');
                                    jQuery('#sucess-mess').css('display', 'block');
                                    setTimeout(function(){ jQuery("#sucess-mess").css('display','none'); },1000);
                                    }
                         });
                    }
                    else{                         
                      alert("Ingen fil vald");                    
                    }
            });
          
      });
});
