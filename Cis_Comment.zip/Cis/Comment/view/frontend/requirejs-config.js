var config = {
    "map": {
        "*": {
             discountCode:'Magento_Checkout/js/discount-codes',
            "Magento_Checkout/js/model/shipping-save-processor/default" : "Cis_Comment/js/shipping-save-processor-default-override",
            "Magento_Checkout/template/shipping.html": "Cis_Comment/template/shipping.html",
            "Magento_Checkout/template/billing-address.html": "Cis_Comment/template/billing-address.html"
            
        }
    }
};
