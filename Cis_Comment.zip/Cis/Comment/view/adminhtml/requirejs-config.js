var config = {
    "map": {
        "*": {
            "Magento_Sales/template/order/view/info.phtml": "Oye_Deliverydate/template/order/view/info.phtml"
            
        }
    }
};


